namespace Fonet.Fo.Properties
{
    internal class TableOmitHeaderAtBreak : GenericBoolean.Enums { }
}
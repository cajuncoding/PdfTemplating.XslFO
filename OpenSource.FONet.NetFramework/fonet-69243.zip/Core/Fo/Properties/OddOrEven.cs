namespace Fonet.Fo.Properties
{
    internal class OddOrEven
    {
        public const int ODD = Constants.ODD;

        public const int EVEN = Constants.EVEN;

        public const int ANY = Constants.ANY;

    }
}
namespace Fonet.Fo.Properties
{
    internal class DisplayAlign
    {
        public const int BEFORE = Constants.BEFORE;

        public const int AFTER = Constants.AFTER;

        public const int CENTER = Constants.CENTER;

        public const int AUTO = Constants.AUTO;

    }
}
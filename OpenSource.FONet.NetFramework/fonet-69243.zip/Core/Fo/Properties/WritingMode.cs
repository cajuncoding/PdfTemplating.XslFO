namespace Fonet.Fo.Properties
{
    internal class WritingMode
    {
        public const int LR_TB = Constants.LR_TB;

        public const int RL_TB = Constants.RL_TB;

        public const int TB_RL = Constants.TB_RL;

    }
}
namespace Fonet.Fo.Properties
{
    internal class WrapOption
    {
        public const int WRAP = Constants.WRAP;

        public const int NO_WRAP = Constants.NO_WRAP;

    }
}
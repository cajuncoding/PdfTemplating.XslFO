namespace Fonet.Fo.Properties
{
    internal class PagePosition
    {
        public const int FIRST = Constants.FIRST;

        public const int LAST = Constants.LAST;

        public const int REST = Constants.REST;

        public const int ANY = Constants.ANY;

    }
}
namespace Fonet.Fo.Properties
{
    internal class BorderEndWidth
    {
        internal class Conditionality : GenericCondBorderWidth.Enums.Conditionality { }

    }
}
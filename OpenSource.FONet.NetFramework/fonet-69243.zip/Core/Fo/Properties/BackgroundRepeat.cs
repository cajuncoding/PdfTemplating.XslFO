namespace Fonet.Fo.Properties
{
    internal class BackgroundRepeat
    {
        public const int REPEAT = Constants.REPEAT;

        public const int REPEAT_X = Constants.REPEAT_X;

        public const int REPEAT_Y = Constants.REPEAT_Y;

        public const int NO_REPEAT = Constants.NO_REPEAT;

        public const int INHERIT = Constants.INHERIT;

    }
}
namespace Fonet.Fo.Properties
{
    internal class PaddingBefore
    {
        internal class Conditionality : GenericCondLength.Enums.Conditionality { }

    }
}
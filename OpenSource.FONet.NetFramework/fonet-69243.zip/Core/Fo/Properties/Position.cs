namespace Fonet.Fo.Properties
{
    internal class Position
    {
        public const int STATIC = Constants.STATIC;

        public const int RELATIVE = Constants.RELATIVE;

        public const int ABSOLUTE = Constants.ABSOLUTE;

        public const int FIXED = Constants.FIXED;

    }
}
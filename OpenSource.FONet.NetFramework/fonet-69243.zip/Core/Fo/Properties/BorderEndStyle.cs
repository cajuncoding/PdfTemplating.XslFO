namespace Fonet.Fo.Properties
{
    internal class BorderEndStyle
        : GenericBorderStyle.Enums { }
}
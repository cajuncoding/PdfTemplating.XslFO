namespace Fonet.Fo.Properties
{
    internal class BlankOrNotBlank
    {
        public const int BLANK = Constants.BLANK;

        public const int NOT_BLANK = Constants.NOT_BLANK;

        public const int ANY = Constants.ANY;

    }
}
namespace Fonet.Fo.Properties
{
    internal class LetterValue
    {
        public const int ALPHABETIC = Constants.ALPHABETIC;

        public const int TRADITIONAL = Constants.TRADITIONAL;

        public const int AUTO = Constants.AUTO;

    }
}
namespace Fonet.Fo.Properties
{
    internal class BorderBeforeWidth
    {
        internal class Conditionality : GenericCondBorderWidth.Enums.Conditionality { }

    }
}
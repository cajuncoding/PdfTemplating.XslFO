namespace Fonet.Fo.Properties
{
    internal class KeepWithNext
    {
        internal class WithinPage : GenericKeep.Enums.WithinPage { }

        internal class WithinLine : GenericKeep.Enums.WithinLine { }

        internal class WithinColumn : GenericKeep.Enums.WithinColumn { }

    }
}
namespace Fonet.Fo.Properties
{
    internal class KeepWithPrevious
    {
        internal class WithinPage : GenericKeep.Enums.WithinPage { }

        internal class WithinLine : GenericKeep.Enums.WithinLine { }

        internal class WithinColumn : GenericKeep.Enums.WithinColumn { }

    }
}
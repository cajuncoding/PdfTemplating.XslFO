namespace Fonet.Fo.Properties
{
    internal class BorderBottomStyle
        : GenericBorderStyle.Enums { }
}
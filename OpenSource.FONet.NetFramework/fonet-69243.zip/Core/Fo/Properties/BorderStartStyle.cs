namespace Fonet.Fo.Properties
{
    internal class BorderStartStyle
        : GenericBorderStyle.Enums { }
}
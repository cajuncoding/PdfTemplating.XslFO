namespace Fonet.Fo.Properties
{
    internal class BorderAfterWidth
    {
        internal class Conditionality : GenericCondBorderWidth.Enums.Conditionality { }

    }
}
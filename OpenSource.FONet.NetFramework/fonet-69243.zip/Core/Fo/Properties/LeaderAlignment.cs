namespace Fonet.Fo.Properties
{
    internal class LeaderAlignment
    {
        public const int NONE = Constants.NONE;

        public const int REFERENCE_AREA = Constants.REFERENCE_AREA;

        public const int PAGE = Constants.PAGE;

    }
}
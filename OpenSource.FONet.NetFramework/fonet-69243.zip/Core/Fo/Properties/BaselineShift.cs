namespace Fonet.Fo.Properties
{
    internal class BaselineShift
    {
        public const int BASELINE = Constants.BASELINE;

        public const int SUB = Constants.SUB;

        public const int SUPER = Constants.SUPER;

    }
}
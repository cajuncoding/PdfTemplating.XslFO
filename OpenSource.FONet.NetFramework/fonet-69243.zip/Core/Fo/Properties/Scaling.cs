namespace Fonet.Fo.Properties
{
    internal class Scaling
    {
        public const int UNIFORM = Constants.UNIFORM;

        public const int NON_UNIFORM = Constants.NON_UNIFORM;

    }
}
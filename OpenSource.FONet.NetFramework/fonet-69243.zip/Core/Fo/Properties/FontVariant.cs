namespace Fonet.Fo.Properties
{
    internal class FontVariant
    {
        public const int NORMAL = Constants.NORMAL;

        public const int SMALL_CAPS = Constants.SMALL_CAPS;

    }
}
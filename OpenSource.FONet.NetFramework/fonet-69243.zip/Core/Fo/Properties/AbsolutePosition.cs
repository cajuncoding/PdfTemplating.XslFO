namespace Fonet.Fo.Properties
{
    internal class AbsolutePosition
    {
        public const int AUTO = Constants.AUTO;

        public const int FIXED = Constants.FIXED;

        public const int ABSOLUTE = Constants.ABSOLUTE;

        public const int INHERIT = Constants.INHERIT;

    }
}
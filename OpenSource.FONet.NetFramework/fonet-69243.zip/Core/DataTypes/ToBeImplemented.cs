namespace Fonet.DataTypes
{
    internal class ToBeImplemented
    {
        public ToBeImplemented(string value)
        {
        }
    }
}
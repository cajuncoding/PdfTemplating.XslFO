namespace Fonet.DataTypes
{
    internal interface IPercentBase
    {
        int GetDimension();

        double GetBaseValue();

        int GetBaseLength();
    }
}